README Forecast App V2
----------------------

This app requires RStudio and shiny package for use.
MySQL cannot connect to application when being hosted on 
a remote server. Run locally in RStudio.

Required Packages: shiny !!!UNZIP FOLDER BEFORE RUNNING!!!
		   ggplot2
		   rsconnect
		   forecast
                   tseries
		   DBI		   
		   pool
		   RMySQL
		   knitr
		   grid
		   gridExtra		   

author: james myers 