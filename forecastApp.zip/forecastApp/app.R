# THIS IS THE INTERACTIVE WEBAPP FOR DEMAND FORECASTING (CAN ONLY RUN LOCALLY CURRENTLY)
#MAKE SURE ALL CONTENTS OF 'forecast_apV2' WERE PROPERLY UNZIPPED
#CLICK 'Run App' TO START!!!
library(shiny)
library(knitr)
library(rsconnect)
library(DBI)
library(pool)
library(RMySQL)
library(ggplot2)
library(forecast)
library(tseries)
library(grid)
library(gridExtra)
source('scripts/sqlfetch.R',local=TRUE)
source('scripts/forecasting_v3.R',local=TRUE)
source('scripts/avg_interval.R',local=TRUE)

#PROVIDES FLUID USER INTERFACE WITH PLOTS SHOWN WITH THEIR RESPECTIVE TABLES.
#CURRENTLY ALLOWS USER TO INPUT ITEM NUMBER AND GRAPHS/TABLES WILL AUTOMATICALLY APPEAR!
ui <- fluidPage(
  
  titlePanel("MCH Forecast Information: "),
  fluidRow(
    column(width=7,plotOutput("demandPlot",height=250)),
    column(width=5,plotOutput("forecastPlot",height=250))
  ),
  fluidRow(  
    column(width=6,plotOutput("maTablePlot",height=250,width=500)), 
    column(width=6,plotOutput("fcTablePlot",height=250))
  ),
  
  wellPanel(fluidRow(
    column(width=3,textInput("id","Item ID:",value = 14)),
    column(width=6,p("These are the Demand and Forecast plots based on user entered item. The 80% and 95% columns refer
                      to the likelihood that the predicted forecast will fall in that range of demand. The current order 
                      of moving average is 2 and should be adjusted in the future to better fit data."))
  ))
  
)

#SERVER CONNECTS INTERFACE TO R FUNCTIONS INCLUDED IN THE FOLDER SCRIPTS
server <- function(input, output, session) {
  
  #FUNCTION TO AUTOMATICALLY UPDATE ID NUMBER FOR EACH PLOT
  observe({
    updateTextInput(session,'id',value=prettyNum(input$id))
  }) 
  
  #RENDERS FORECAST PLOT
  output$forecastPlot <- renderPlot({
    
    id <- input$id
    hold <- sqlfetch(id)
    item <- item_gather(id,hold)
    interval <- avg_interval(as.Date(item[,1]))
    fcast <- demand_forecast(id,item)
    plot(fcast,main=c("Forecast for Item ID",id),xlab=c(interval," Day Intervals"),ylab='Demand')
    
  })
  
  #RENDERS DEMAND PLOT WITH MOVING AVERAGE
  output$demandPlot <- renderPlot({ 
    
    id <- input$id
    hold <- sqlfetch(id)
    item <- item_gather(id,hold)
    ggplot() + geom_line(data = item,aes(x=dates,y=clean,colour='actual')) + 
    geom_line(data=item, aes(x=dates,y=d_ma,colour='moving avg(2 intervals)')) + 
    xlab('Time')+ylab('Demand')
    
  })
  
  #RENDERS FORECAST TABLE WITH DATA FOR NEXT 5 TIME INTERVALS BY 1/2 INTERVAL INCREMENTS
  output$fcTablePlot <- renderPlot({ 
    
    id <- input$id
    hold <- sqlfetch(id)
    item <- item_gather(id,hold)
    fcast <- demand_forecast(id,item)
    fc_frame <- frame_gather(fcast)
    t <- ttheme_default()
    fc_table <- tableGrob(fc_frame)
    grid.draw(fc_table)
    
  })
  
  #RENDERS TABLE WITH DEMAND FOR PAST 10 ORDERS WITH INCLUDED MOVING AVERAGE
  output$maTablePlot <- renderPlot({ 
    
    id <- input$id
    hold <- sqlfetch(id)
    item <- item_gather(id,hold)
    colnames(item) <- c('Last 10 Dates','Amount Dispensed','Moving Average')
    item_table<-tableGrob(item[(length(item[,1])-10):length(item[,1]),1:3])
    grid.draw(item_table)
    
  })
  #USED FOR DESKTOP APP DEPLOY. CURRENLTY CANNOT CONNECT TO SQL THROUGH DESKTOP APP.
  if (!interactive()) {
    session$onSessionEnded(function() {
      stopApp()
      q("no")
    })
  }

}

#CREATES APPLICATION USING USER INTERFACE AND SERVER PREFERENCES PREVIOUSLY DEFINED
shinyApp(ui = ui, server = server)
