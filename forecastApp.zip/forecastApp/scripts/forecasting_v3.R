library(ggplot2)
library(forecast)
library(tseries)

#PREDICTS FUTURE DEMAND BASED ON STL (SEASONAL AND TREND DECOMPOSITION USING LOESS)
#STATIONARY TEST NEEDS TO HAVE A p-VALUE of > 0.05 FOR DATA TO BE CONSIDERED VALID
#FOR USE IN FORECASTING MODEL. CURRENT FREQUENCY IS SET AT 2 AND AMOUNT OF PREDICTIONS
# IS SET AT 10 MEANING THERE ARE 5 PREDICTED TIME INTERVALS (LENGTH OF INTERVAL DISPLAYED
#ON FORECAST GRAPH).
demand_forecast <- function(x,y){
  
  id <- x
  item <- y
  d_ma <- item$d_ma
  print(d_ma)
  count_ma <- ts(na.omit(d_ma),frequency=2)
  
  decomp <- stl(count_ma,s.window='periodic')
  deseasonal_d <- seasadj(decomp)
  
  stationary_test <- adf.test(count_ma,alternative='stationary')
  
  demand <- diff(deseasonal_d, differences=2)
  
  fit <- auto.arima(deseasonal_d,seasonal=F)

  fit_hold <- fit[["arma"]]
  i <- 1
  if(fit_hold[1]==0){
    fit_order <- fit_hold[2:4]
  }else {
    fit_order <- fit_hold[1:3]
  }
  fit2 <- arima(deseasonal_d,order=fit_order)
  fcast <- forecast(fit2,h=10)
  return(fcast)
}

#CLEANS DATA AND CALCULATES MOVING AVERAGE OF DEMAND FOR DATA. 
#MOVING AVERAGE ORDER IS CURRENTLY SET AT 2 DUE TO LACK OF DATA.
#ORDER SHOULD BE ADJUSTED TO BETTER FIT TREND WHEN MORE DATA IS COLLECTED
item_gather <- function(x,y){  
  id <- x
  item <- y
  colnames(item) <- c('id','dates')
  dates <- item[,2]
  dates <- as.Date(dates)
  interval <- avg_interval(dates)

  count_ts <- ts(item[,c('id')])

  item$clean = tsclean(count_ts)
  clean <- item$clean
  item$d_ma = ma(clean,order=2)
  d_ma <- item$d_ma

  item <- data.frame(dates,clean,d_ma,id)
  return(item)
}

#TAKES DATA FROM FORECASTING TO PROJECT IN A TABLE FOR APPLICATION.  
frame_gather <- function(fcast){  
  
  fc_frame <- data.frame(fcast)
  point <- rownames(fc_frame)
  rownames(fc_frame) <- NULL
  point <- as.numeric(point)
  point <- round(point,digits=2)
  i <- 1
  while(i <= 5){  
    fc_frame[,i] <- as.integer(fc_frame[,i])
    i <- i + 1
  }

  fc_frame <- cbind(point,fc_frame)
  colnames(fc_frame) <- c('Point','Forecast','Low 80%','High 80%','Low 95%','High 95%')
  return(fc_frame)
}



