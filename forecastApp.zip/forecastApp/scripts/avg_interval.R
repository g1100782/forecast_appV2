#SIMPLE FUNCTION TO CALCULATE AVERAGE INTERVAL OF TIME BETWEEN ORDERS
avg_interval <- function(dates){
    dates <- format(dates,"%j")
    dates <- as.numeric(dates)
    interval_v <- c()
    i <- 1
    while(i < length(dates)){
      interval_v[i] <- dates[i+1] - dates[i]
      if(interval_v[i] <= 0){
        interval_v[i] <- 365 + dates[i+1] - dates[i]
        i <- i + 1
      } else{
        i <- i + 1
      }
    }
    interval <- sum(interval_v) / length(interval_v)
    return(interval)
}
