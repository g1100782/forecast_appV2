library(DBI)
library(RMySQL)

#COLLECTS DATA FOR MySQL DATABASE. CURRENTLY PULLS DATA FROM MCH WARD 
#BECAUSE ALL OTHER WARDS HAVE INSUFFICIENT DATA FOR A TIME SERIES (NECESSITY FOR STL).
#SQL QUERY FOR ITEM CAN EASILY BE MODIFIED TO FORECAST DEMAND FOR OTHER WARDS BY 
#MODIFYING 'stock_status_mch' TO OTHER WARD DESTINATION NAME AND 'MCH_REGISTER' TO WARDS 
#RESPECTIVE DISPENSING FORM. NOTE THAT MOST ITEMS DO NOT HAVE ENOUGH DATA TO PREDICT FUTURE DEMAND 
#(ITEM 14 AND 22 ARE THE ONLY 2 ITEMS ACROSS ALL WARDS THAT CAN PERFORM THIS ANALYSIS.)

sqlfetch <- function(id){
    con <- dbConnect(MySQL(),port=3306,user='g1100782',password='Team2Website',dbname='g1100782',host='mydb.itap.purdue.edu')
    item <- dbGetQuery(con, paste("select sum(item_movement),updated_date from stock_status_mch where item_id =",
                                  id,"and form='MCH_REGISTER' group by updated_date",sep=" "))
    colnames(item) <- c(id,'dates')
    dbDisconnect(con)
    return(item)
}
